import { Component, HostListener } from '@angular/core';
import { DataService} from './services/data.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'app';
  constructor(private dataService: DataService){

  }
  
  // @HostListener('scrollTo') onHover() {
  //   window.alert("hover");
  // }
}
